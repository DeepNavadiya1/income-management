<?php
include("headerr.php");

?>

<!-- Page Content -->
<div style="margin-left:20%">

<div class="w3-container w3-teal">
  <h1><center>Home</center></h1>
</div><br><br>
<div class="container">
<div class="row"style="color:#009688;" >
<div class="col-lg-3">
 <div class="box-3">
  <div class="btn btn-three"><a href="index.php" class="w3-bar-item w3-button"><i class="fa fa-home" style="font-size:80px" aria-hidden="true"></i> Home</a></div></div></div>
  
  
  <div class="col-lg-3">
   <div class="box-3" >
  <div class="btn btn-three"><a href="addaccount.php" class="w3-bar-item w3-button"><i class="fa fa-user-plus" style="font-size:80px" aria-hidden="true"></i> Add Account</a></div></div></div>
  
  
  <div class="col-lg-3">
  <div class="box-3" >
  <div class="btn btn-three">
  <a href="accountregister.php" class="w3-bar-item w3-button"><i class="fa fa-pencil-square-o"style="font-size:80px" aria-hidden="true"></i> Account Register</a></div></div></div>
  
  
  <div class="col-lg-3">
  <div class="box-3" >
  <div class="btn btn-three">
  <a href="updateaccount.php" class="w3-bar-item w3-button"><i class="fa fa-refresh"style="font-size:80px" aria-hidden="true"></i> Update Account</a></div></div></div></div>
  
  
  
  <div class="row"style="color:#009688;">
  <div class="col-lg-3">
  <div class="box-3" >
  <div class="btn btn-three">
  <a href="payin.php" class="w3-bar-item w3-button"><i class="fa fa-money"style="font-size:80px" aria-hidden="true"></i> Pay In</a>
  </div></div></div>
  
  
  <div class="col-lg-3">
  <div class="box-3" >
  <div class="btn btn-three">
  <a href="payout.php" class="w3-bar-item w3-button"><i class="fa fa-money"style="font-size:80px" aria-hidden="true"></i> Pay Out</a>
  </div></div></div>
  
  <div class="col-lg-3">
  <div class="box-3" >
  <div class="btn btn-three">
  <a href="ledger.php" class="w3-bar-item w3-button">
<i class="fa fa-book"style="font-size:80px" aria-hidden="true"></i> Ledger</a></div></div></div>


<div class="col-lg-3">
<div class="box-3" >
  <div class="btn btn-three">
  <a href="payinregister.php" class="w3-bar-item w3-button"><i class="fa fa-credit-card"style="font-size:80px" aria-hidden="true"></i>
Pay In Register</a></div></div></div></div>


<div class="row"style="color:#009688;">
  <div class="col-lg-3">
<div class="box-3" >
  <div class="btn btn-three">
  <a href="payoutregister.php" class="w3-bar-item w3-button"><i class="fa fa-credit-card" style="font-size:80px"aria-hidden="true"></i>
Pay Out Register</a></div></div></div>



  
  <div class="col-lg-3">
  <div class="box-3" >
  <div class="btn btn-three">
  <a href="#" class="w3-bar-item w3-button"><i class="fa fa-sign-out"style="font-size:80px" aria-hidden="true"></i>Log Out</a></div></div></div>
  </div>
 
</div>
      
	 
	  
</body>
</html>
